#ifndef CANDY_H
#define CANDY_H

class definition goes here

#endif