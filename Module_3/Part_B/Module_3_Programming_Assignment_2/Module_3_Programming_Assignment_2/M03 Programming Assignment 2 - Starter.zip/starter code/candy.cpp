#include "candy.h"

class implementation goes here
