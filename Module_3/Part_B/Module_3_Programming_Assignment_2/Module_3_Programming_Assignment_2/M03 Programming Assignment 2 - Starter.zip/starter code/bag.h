#ifndef BAG_H
#define BAG_H

class definition goes here

#endif