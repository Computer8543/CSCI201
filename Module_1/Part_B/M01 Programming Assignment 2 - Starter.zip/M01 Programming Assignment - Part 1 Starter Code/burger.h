#ifndef BURGER_H
#define BURGER_H

//Your class goes here

#endif