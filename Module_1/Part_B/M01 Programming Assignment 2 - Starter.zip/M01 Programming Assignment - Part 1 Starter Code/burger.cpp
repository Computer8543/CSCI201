don't forget to include the class header file
//class implementation goes here