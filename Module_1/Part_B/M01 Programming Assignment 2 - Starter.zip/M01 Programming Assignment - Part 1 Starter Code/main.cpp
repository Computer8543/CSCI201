#include <iostream>
#include <string>
#include <climits>
#include <iomanip
don't forget your class header
