#ifndef CHARACTER_H
#define CHARACTER_H
#include <string>

classes go here

#endif